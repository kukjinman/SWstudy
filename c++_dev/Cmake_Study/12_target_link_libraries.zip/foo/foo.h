
void foo();