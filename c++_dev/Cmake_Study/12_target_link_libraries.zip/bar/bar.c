#include <stdio.h>

void bar()
{
    printf("bar\n");
}