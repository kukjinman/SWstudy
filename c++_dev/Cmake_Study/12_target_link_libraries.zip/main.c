#include "bar.h"
#include "foo.h"

int main()
{
    foo();
    bar();

    return 0;
}